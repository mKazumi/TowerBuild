<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\SiteList;
class SiteListController extends Controller
{
  public function Home(){
    $sitelists = SiteList::all();
    return view('home',['sitelists' => $sitelists]);
  }
  public function addSiteList(Request $request){
    $this->validate($request,[
      'provinsi'=> 'required',
      'kabupaten'=> 'required',
      'kecamatan'=> 'required',
      'desa'=> 'required'
    ]);
    return 'Validation Pass';
  }


}

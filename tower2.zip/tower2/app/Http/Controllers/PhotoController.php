<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PhotoController extends Controller
{
  public function __construct()
  {
    $this->middleware('web');
  }
  public function documentation()
  {
    return view('gambar');
  }

}

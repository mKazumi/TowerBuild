<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Menu extends Model
{
  protected $table = 'menus';
  protected $fillable = ['menu'];
  protected $primaryKey = 'id';
  public $timestamps = false;

  public function users()
  {
  return  $this->hasMany('App\User','role_id','id');
  }
}

<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SiteList extends Model
{
  protected $table = 'site_lists';
  protected $fillable = ['provinsi','kabupaten','kecamatan','desa','penyedia','target_409','usulan_pemda'];
  protected $primaryKey = 'id_sitelist';
  public $timestamps = false;
}

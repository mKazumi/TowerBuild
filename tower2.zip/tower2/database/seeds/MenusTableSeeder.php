<?php

use Illuminate\Database\Seeder;

class MenusTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
      Menu::insert ([
        ['menu'=>'Smart Goverment'],
        ['menu'=>'Smart Environment'],
        ['menu'=>'Smart Living'],
        ['menu'=>'Smart People'],
        ['menu'=>'Smart Economy'],
        ['menu'=>'Smart Mobility']

      ]);
    }
}
